#pragma once
class Menu
{
public:
	Menu();
	void StartNewGame(bool isActorFirst);
	void AutoShipLayoutForActor();
};

