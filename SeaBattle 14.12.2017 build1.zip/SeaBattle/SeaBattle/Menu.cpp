#include "stdafx.h"
#include "Menu.h"


Menu::Menu()
{
}
