#include "stdafx.h"
#include "Cell.h"


void Cell::SetDisabled()
{
	_isDisabled = true;
}

bool Cell::IsDisabled() const
{
	return _isDisabled;
}

Cell::Cell(const MatrixPoint gPoint, const bool visible, const CRect rect, const GameFieldItemMark mark) :
	Cell(gPoint, visible, rect, mark, CellState::Available)
{
}

Cell::Cell(const MatrixPoint gPoint, const bool visible, const CRect rect, const GameFieldItemMark mark, const CellState state)
	: GameFieldItem(gPoint, visible, rect, mark),
	_isDisabled(false),
	_state(state)
{
}

void Cell::Show(CPaintDC * dc)
{
	const auto oldBrush = dc->GetCurrentBrush();
	const auto oldPen = dc->GetCurrentPen();
	CBrush newBrush;
	CPen newPen;
	newBrush.CreateSolidBrush(RGB(216, 248, 255));
	newPen.CreatePen(PS_SOLID, 1, RGB(255, 255, 255));
	dc->SelectObject(newBrush);
	dc->SelectObject(newPen);
	dc->Rectangle(GetRect());
	dc->SelectObject(oldBrush);
	dc->SelectObject(oldPen);
	GameFieldItem::Show(dc);
}

void Cell::SetState(const CellState state)
{
	_state = state;
}

Cell::CellState Cell::GetState() const
{
	return _state;
}

